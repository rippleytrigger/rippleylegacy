
	<div class="container-fluid bg-3 text-center">    
		<div class="box">
			<header class="jumbotron" style="background: lightblue;">
					
			  <div class="container-fluid text-center">
			    <h1>¿Deseas ver algunas muestras de mi trabajo?</h1>     

			    <p>Dale click a las imágenes para ver mis proyectos de forma on-line</p>
			  </div>
			
				<div class="row">
					<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 margin-5">
						<div class="image-wrapper">
								<img src="img y videos/logo federales.jpg" 
								class="img-responsive" alt="Image" />
						</div>
						<a href="http://www.rippleys.260mb.net/proyecto_uneweb/" 
						class="btn btn-warning btn-block">
								Los Federales
						</a>
					</div>
					<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 margin-5">
						<div class="image-wrapper">
								<img src="img y videos/universitas.jpg" 
								class="img-responsive" alt="Image" />
						</div>
						<a href="javascript:void(0)" class="btn btn-info btn-block">
								Falta Aprovación del cliente
						</a>
					</div>
					<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 margin-5">
						<div class="image-wrapper">
								<img src="img y videos/drkids.jpg" 
								class="img-responsive" alt="Image" />
						</div>
						<a href="javascript:void(0)" class="btn btn-danger btn-block">
								En Curso
						</a>
					</div>
				</div>
				<div class="row">
					<h2 class="margin-5">Aportes en otros proyectos</h2>

					<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 margin-5">
						<div class="image-wrapper">
								<img src="img y videos/logoscorp.jpg" 
								class="img-responsive" alt="Image" />
						</div>
						<a href="http://logoscorp.com/en/" 
						class="btn btn-success btn-block">
								Logoscorp
						</a>
					</div>
					<div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 margin-5">
						<div class="image-wrapper">
								<img src="img y videos/lifeinvest.jpg" 
								class="img-responsive" alt="Image" />
						</div>
						<a href="http://lifeinvestasset.com/en/" class="btn btn-default btn-block">
								LifeInvestAsset
						</a>
					</div>
				</div>
			</header>

		</div>
	</div>