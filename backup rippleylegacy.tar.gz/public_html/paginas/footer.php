
      <footer>

        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 text-center">

                     <div class="copyright">
                          Copyright &copy; Rippleylegacy  <?php echo '('.date('Y').')'; ?>.  Diseñado por Marcos López.
                     </div>

                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <!--<script src="js/jquery.js"></script>-->

    <script
    src="https://code.jquery.com/jquery-3.1.1.js"
    integrity="sha256-16cdPddA6VdVInumRGo6IbivbERE8p7CQR3HzTBuELA="
    crossorigin="anonymous"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript" src="js/main.js"></script>

    <?php require_once 'includes/google-analytics.php'; ?>


</body>

</html>