
              

                  <!--<div class="facebook">
                  

                  <a href="https://www.facebook.com/pg/rippleylegacy/">
                    
                     <i class="fa fa-facebook" aria-hidden="true"></i>

                  </a>
          
                 

                  </div>-->
                  
                
                  <!--<div class="twitter">

                  <a href="">

                       <i class="fa fa-twitter" aria-hidden="true"></i>
                  </a>
                        
                       </div>-->
  
                
                 
                
                 <!--<div class="instagram">

                  <a href="https://www.instagram.com/rippleylegacy_2017/">
                  
                  <i class="fa fa-instagram" aria-hidden="true"></i>
      
                  </a>
                  </div>-->

                  
                
                  <div class="linkedin">

                  <a href="https://www.linkedin.com/in/marcos-lopez-3ba024121/">
                      
                      <i class="fa fa-linkedin" aria-hidden="true"></i>

                  </a>


                 </div>

                 