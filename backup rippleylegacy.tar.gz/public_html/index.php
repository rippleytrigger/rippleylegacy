
    <?php  require_once 'paginas/head.php'; ?> 
    
    <header id="inicio">

        <?php require_once 'paginas/nav.php'; ?>

	</header>
    <!-- Img central -->

 
    <div class="container-fluid img_central">
        
      
    </div>
  
 	<!-- FIN  -->

     <section class="container">

     		<div class="row">
					
			
	     			<article class="col-md-12">

	     				<?php require_once 'paginas/intro.php'; ?>
	
     				
	     			</article>

	     			<article class="col-md-4">
	     				

	     			</article>	
     		</div> 

	 </section>

	  <section class="container-fluid" id="quien_soy">

		<?php require_once 'paginas/quien_soy.php'; ?> 	 	
 	 	
 	 </section>

	 <section class="container-fluid img_2" id="servicios">

	
				<?php require_once 'paginas/serv_.php'; ?>

			
	 </section>



	 <section class="container" id="Portafolio" >

	 	<?php  require_once 'paginas/portafolio.php'; ?>
	 	
	 </section>

	 <section class="container" id="contacto">

	 	<?php require_once 'paginas/contacto.php'; ?>
	 	
	 </section>

	 
    <?php require_once 'paginas/footer.php'; ?>